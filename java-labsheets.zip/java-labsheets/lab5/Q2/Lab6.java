
package lab6;

public class Lab6 {

    public static void main(String[] args) 
    {
        politician p1=new politician();
        p1.speak("Vote me");
        
        priest p2=new priest();
        p2.speak("bless you");
        
        lecturer p3=new lecturer();
        p2.speak("Hi.. students");
        
        
               
        
    }
    
}
