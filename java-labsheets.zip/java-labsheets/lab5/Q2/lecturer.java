
package lab6;

public class lecturer implements speaker
{
    public void speak(String phase)
    {
        System.out.println(i+" Lecture Says: "+phase);
    }

   
      
}
