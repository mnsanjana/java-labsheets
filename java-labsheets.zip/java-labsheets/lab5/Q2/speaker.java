
package lab6;

public interface speaker 
{
    int i=100;
    void speak(String line);
    
}
