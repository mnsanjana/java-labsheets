
package lab6;

public class priest implements  speaker
{

    public void speak(String phase) 
    {
        System.out.println(i+" Priest says: "+ phase);
    }

    
}
