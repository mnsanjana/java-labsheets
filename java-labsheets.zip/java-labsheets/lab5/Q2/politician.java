
package lab6;

public class politician implements speaker
{

    @Override
    public void speak(String phase) 
    {
        System.out.println(i+" Plotician Says: "+phase);
    }

   
    
}
