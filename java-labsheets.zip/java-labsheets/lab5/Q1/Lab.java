
package lab;

public class Lab implements MyFirstinterface {

    public static void main(String[] args) 
    
    {
        
        Lab i1=new Lab() {};
        i1.display();
    
    }
    
    public void display() 
    {
         int x=10;
         System.out.println(x);
    }
}
