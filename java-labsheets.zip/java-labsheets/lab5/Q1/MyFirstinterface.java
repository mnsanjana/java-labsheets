
package lab;



public interface MyFirstinterface 
{
  final int x=5;
  void display();
    
}
