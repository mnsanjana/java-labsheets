
package q1;

public class items 
{
    private int location;
    private String description;
    
    public void setValues(int location, String description)
    {
        this.location=location;
        this.description=description;
    }

    
    public int getlocation()
    {
        return location;
    }
    
    public String getdescription()
    {
        return description;
    }
}
