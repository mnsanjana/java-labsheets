
package q1;

public class Q1 
{

    public static void main(String[] args) 
    {
       Monster m1=new Monster();
       m1.setValues(5, "Colombo");
       System.out.println("Location is: "+m1.getdescription());
        
    }
    
}
