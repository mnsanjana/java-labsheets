
package q1;

public class Monster extends items

{
   
    
   public void Monster(int location, String description ) 
    {
         
    }
    
}

