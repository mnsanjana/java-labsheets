
package q2;

public class Q2 {

    public static void main(String[] args) 
    {
         q2class  c1=new  q2class ("Saman", 25000.00f, 3000.00f);
       
        System.out.println("Name is: "+c1.getname());
        System.out.println("Basic Salary is: "+c1.getbsalary());
        System.out.println("Bonus is : "+c1.getbonus());
        System.out.println("Anouth is : "+ c1.getbamouth());
    }
    
}
