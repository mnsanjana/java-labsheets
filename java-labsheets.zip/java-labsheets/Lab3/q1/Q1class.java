
package q1;

public class Q1class 
{
     private String name;
    private int age;
    private float salary;
    
    public void setname(String a)
    {
        name=a;
    }
    public void setage(int b)
    {
        age=b;
    }
    public void setsalary(float c)
    {
        salary=c;
    }
    public String getname()
    {
        return name;
    }
    public int getage()
    {
        return age;
    }
    public float getsalary()
    {
        return salary;
    }
}
