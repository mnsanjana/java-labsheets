
package q1;

public class Q1class2 
{
   
    
    private String name;
    private int age;
    private float salary;
    
    public Q1class2(String a, int b, float c)
    {
        name=a;
        age=b;
        salary=c;
        
    }
    
    public void display()
    {
        System.out.println(" ");
        System.out.println("Name is: "+name);
        System.out.println("Age is: "+age);
        System.out.println("Salary is "+salary);
    }
}
