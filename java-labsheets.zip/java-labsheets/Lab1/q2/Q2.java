
package q2;

public class Q2 {

    public static void main(String[] args) 
    {
        System.out.println("Name: Dasuni");
        System.out.println("Degree Programe: BSc Management Information System");
    }
    
}
