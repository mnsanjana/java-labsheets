
package q5;

public class Q5 {

    public static void main(String[] args)
    {
        
        q5class q=new q5class();
        
    }
    
}
