
package q3;

public class Q3 {

    public static void main(String[] args) 
    
    {
        for(int x=0; x<5; x++)
        {
            System.out.println("Executing Loop: "+x);
        }
        
        System.out.println(" ");
        
        int y=0;
        while(y<5)
        {
            System.out.println("Executing Loop: "+y);
            y++;
        }
    }
    
}
