
package q4;

public class Q4 {

    public static void main(String[] args) 
    {
        q4clas q=new q4clas();
    }
    
}
