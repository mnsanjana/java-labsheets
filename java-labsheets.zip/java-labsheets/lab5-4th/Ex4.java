package ex4;

public class Ex4 {

    public static void main(String[] args) 
    {
       circle c1=new circle();
       c1.circle(7);
       c1.calculateArea();
       c1.display();
       
       rectangle r1=new rectangle();
      r1.rectangle(20, 30);
       r1.calculateArea();
       r1.display();
    }
    
}
