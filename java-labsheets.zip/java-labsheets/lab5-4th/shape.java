
package ex4;

public abstract class shape 
{
     
   
    abstract void calculateArea();
   
    void display()
    {
       
    }
   
}

 

