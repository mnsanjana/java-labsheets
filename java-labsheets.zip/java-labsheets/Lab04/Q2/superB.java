/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab5;

/**
 *
 * @author user
 */
class superB 
{
    int x;
    void setlt(int n)
    {
        x=n;
    }
    void increment()
    {
       x=x+1; 
    }
    void triple()
    {
        x=x*3;
    }
    int returnlt()
    {
        return x;
    }
}
