
package lab5;

class SubC extends superB
{
    void triple()
    {
        x=x+3;
    }
    void quadruple()
    {
        x=x*4;
    }
}
